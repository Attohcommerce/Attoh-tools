/* Oceisa theme additions (20-11): product tabs and the delivery estimate on the product page. */
(function () {
  'use strict';

  /* ---------- product tabs ---------- */
  function initTabs(root) {
    if (root.dataset.ocReady) return;
    root.dataset.ocReady = '1';
    var tabs = Array.prototype.slice.call(root.querySelectorAll('[data-oc-tab]'));
    var panels = Array.prototype.slice.call(root.querySelectorAll('[data-oc-panel]'));
    if (!tabs.length) return;
    function select(i, focus) {
      tabs.forEach(function (t, n) {
        var on = n === i;
        t.classList.toggle('is-active', on);
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        if (on) { t.removeAttribute('tabindex'); } else { t.setAttribute('tabindex', '-1'); }
      });
      panels.forEach(function (p, n) { p.hidden = n !== i; });
      if (focus) tabs[i].focus();
      var list = tabs[i].parentElement;
      if (list && list.scrollWidth > list.clientWidth) {
        list.scrollTo({ left: tabs[i].offsetLeft - 16, behavior: 'smooth' });
      }
    }
    tabs.forEach(function (t, i) {
      t.addEventListener('click', function () { select(i, false); });
      t.addEventListener('keydown', function (e) {
        var next = null;
        if (e.key === 'ArrowRight') next = (i + 1) % tabs.length;
        if (e.key === 'ArrowLeft') next = (i - 1 + tabs.length) % tabs.length;
        if (e.key === 'Home') next = 0;
        if (e.key === 'End') next = tabs.length - 1;
        if (next !== null) { e.preventDefault(); select(next, true); }
      });
    });
  }

  /* ---------- delivery estimate ---------- */
  function addBusinessDays(from, days) {
    var d = new Date(from.getTime());
    var left = days;
    while (left > 0) {
      d.setDate(d.getDate() + 1);
      var day = d.getDay();
      if (day !== 0 && day !== 6) left -= 1;
    }
    return d;
  }
  function initAvail(el) {
    if (el.dataset.ocReady) return;
    el.dataset.ocReady = '1';
    var out = el.querySelector('[data-oc-range]');
    if (!out) return;
    var min = parseInt(el.dataset.min, 10) || 4;
    var max = parseInt(el.dataset.max, 10) || 10;
    var locale = el.dataset.locale || document.documentElement.lang || 'en';
    var fmt;
    try {
      fmt = new Intl.DateTimeFormat(locale, { weekday: 'short', day: 'numeric', month: 'short' });
    } catch (err) {
      fmt = new Intl.DateTimeFormat('en', { weekday: 'short', day: 'numeric', month: 'short' });
    }
    var now = new Date();
    out.textContent = fmt.format(addBusinessDays(now, min)) + ' – ' + fmt.format(addBusinessDays(now, max));
  }

  function boot(scope) {
    (scope || document).querySelectorAll('[data-oc-tabs]').forEach(initTabs);
    (scope || document).querySelectorAll('[data-oc-avail]').forEach(initAvail);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { boot(); });
  } else {
    boot();
  }
  document.addEventListener('shopify:section:load', function (e) { boot(e.target); });
})();
