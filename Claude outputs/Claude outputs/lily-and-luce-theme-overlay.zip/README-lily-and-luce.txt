LILY & LUCE — theme overlay (gebouwd op het EMC-thema, 16-9-2026)

Deze 23 bestanden zijn de enige verschillen t.o.v. het EMC-thema (emc v2 — slider fix 15-9).
Gebruik: upload eerst het EMC-thema (Download theme file → Add theme → Upload zip) in de
Lily & Luce-store (jzmikt-ap). Daarna deze bestanden eroverheen zetten — via Claude (API,
ongepubliceerd thema) of handmatig via Edit code.

Palet (van Soul Society Boutique): ink #2A3743 · deep #2B2825 · taupe #6E6862 · light #F5F5F5 ·
border #E0DFDF · sale #C20000 / #CE0000. Fonts: Tenor Sans (koppen) + Outfit (body).

Nog in de store zelf aanmaken (geen themabestanden):
- Collecties met handle: women, men, shoes, sale (homepage + tegels wijzen daarnaar)
- Menu's: main-menu (Home · Women ▾ · Men ▾ · Sale · Track Your Order · Contact · About Us · FAQ) en store-policies
- Pagina's: about-us, contact, faq, track-your-order, shipping-policy, return-refund-policy
- Logo (header toont nu de storenaam als tekst), favicon, hero-foto, story-foto
- E-mail: info@lilyandluce.com is aangenomen — aanpassen als het anders wordt
- Alle bedrijfsgegevens staan op TBA (footer + contactpagina)
