/* PDP thumbs: actieve foto altijd in beeld in de scrollbare strip + fade als er meer is (30-10) */
(() => {
  const init = (box) => {
    if (!box || box.dataset.uxThumbs) return;
    box.dataset.uxThumbs = '1';
    const update = () => box.classList.toggle('has-more', box.scrollTop + box.clientHeight < box.scrollHeight - 4);
    const reveal = (t) => {
      const b = box.getBoundingClientRect();
      const r = t.getBoundingClientRect();
      if (r.top < b.top) box.scrollTop += r.top - b.top - 8;
      else if (r.bottom > b.bottom - 56) box.scrollTop += r.bottom - b.bottom + 64;
      if (r.left < b.left) box.scrollLeft += r.left - b.left - 8;
      else if (r.right > b.right) box.scrollLeft += r.right - b.right + 8;
    };
    box.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    window.addEventListener('load', update);
    new MutationObserver((list) => {
      list.forEach((m) => { if (m.target !== box && m.target.classList.contains('is-active')) reveal(m.target); });
    }).observe(box, { subtree: true, attributes: true, attributeFilter: ['class'] });
    update();
  };
  const run = () => document.querySelectorAll('.ux-pdp__thumbs').forEach(init);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
  document.addEventListener('shopify:section:load', run);
})();

/* PDP: maat-dropdown stuurt de (verborgen) maatknoppen aan, zodat de bestaande variantlogica blijft werken (30-10) */
(() => {
  const init = (sel) => {
    if (sel.dataset.uxInit) return;
    sel.dataset.uxInit = '1';
    const opt = sel.closest('[data-option-index]');
    const group = opt && opt.querySelector('.ux-pdp__sizes');
    if (!group) return;
    const btns = () => [...group.querySelectorAll('[data-value]')];
    const soldOut = sel.dataset.soldOut || 'Sold out';
    sel.addEventListener('change', () => {
      const b = btns().find((x) => x.dataset.value === sel.value);
      if (b) b.click();
    });
    const sync = () => {
      const on = btns().find((b) => b.classList.contains('is-selected'));
      if (on && sel.value !== on.dataset.value) sel.value = on.dataset.value;
      [...sel.options].forEach((o) => {
        const b = btns().find((x) => x.dataset.value === o.value);
        const label = o.value + (b && b.classList.contains('is-unavailable') ? ' — ' + soldOut : '');
        if (o.textContent !== label) o.textContent = label;
      });
    };
    new MutationObserver(sync).observe(group, { subtree: true, attributes: true, attributeFilter: ['class'] });
    sync();
  };
  const run = () => document.querySelectorAll('[data-size-select]').forEach(init);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
  document.addEventListener('shopify:section:load', run);
})();
