/* Consistent Couture – behaviour for the extra conversion sections (31-10-2026).
   One small file, no dependencies. Every section calls window.CCTSections.init(sectionEl). */
(function () {
  if (window.CCTSections) return;
  var root = document.documentElement;
  root.classList.add('es-js');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var shopRoot = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || '/';

  /* ---------- reveal on scroll ---------- */
  var revealIO = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-in'); revealIO.unobserve(e.target); } });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 }) : null;
  var pending = [], ticking = false, armed = false;
  function sweep() {
    var vh = window.innerHeight;
    pending = pending.filter(function (el) {
      if (el.classList.contains('is-in')) return false;
      if (el.getBoundingClientRect().top < vh + 40) { el.classList.add('is-in'); if (revealIO) revealIO.unobserve(el); return false; }
      return true;
    });
    if (!pending.length) { window.removeEventListener('scroll', onScroll); armed = false; }
  }
  function onScroll() { if (ticking) return; ticking = true; requestAnimationFrame(function () { ticking = false; sweep(); }); }
  function reveal(scope) {
    var els = scope.querySelectorAll('.es-reveal:not(.is-in)');
    if (!revealIO || reduce) { els.forEach(function (el) { el.classList.add('is-in'); }); return; }
    els.forEach(function (el) { revealIO.observe(el); pending.push(el); });
    if (!armed) { armed = true; window.addEventListener('scroll', onScroll, { passive: true }); window.addEventListener('resize', onScroll); }
    setTimeout(sweep, 60);
    window.addEventListener('load', sweep, { once: true });
  }

  /* ---------- horizontal track with arrows + dots ---------- */
  function track(section) {
    var t = section.querySelector('[data-es-track]');
    if (!t) return;
    var prev = section.querySelector('[data-es-prev]');
    var next = section.querySelector('[data-es-next]');
    var dots = section.querySelector('[data-es-dots]');
    var items = [].slice.call(t.children);
    var auto = parseInt(section.getAttribute('data-es-autoplay') || '0', 10);
    var timer;
    function step() { return items.length ? items[0].getBoundingClientRect().width + (parseFloat(getComputedStyle(t).columnGap) || 0) : t.clientWidth; }
    function index() { return Math.round(t.scrollLeft / Math.max(step(), 1)); }
    function perView() { return Math.max(1, Math.round(t.clientWidth / Math.max(step(), 1))); }
    function sync() {
      var max = t.scrollWidth - t.clientWidth - 2;
      if (prev) prev.disabled = t.scrollLeft <= 2;
      if (next) next.disabled = t.scrollLeft >= max;
      if (dots) {
        var i = index(), pages = Math.max(1, items.length - perView() + 1);
        [].slice.call(dots.children).forEach(function (d, k) { d.classList.toggle('is-active', k === Math.min(i, pages - 1)); d.hidden = k >= pages; });
      }
    }
    function go(i) { t.scrollTo({ left: i * step(), behavior: reduce ? 'auto' : 'smooth' }); }
    if (dots) {
      dots.innerHTML = '';
      items.forEach(function (_, k) { var b = document.createElement('button'); b.type = 'button'; b.setAttribute('aria-label', 'Go to ' + (k + 1)); b.addEventListener('click', function () { go(k); }); dots.appendChild(b); });
    }
    if (prev) prev.addEventListener('click', function () { go(Math.max(0, index() - 1)); });
    if (next) next.addEventListener('click', function () { go(index() + 1); });
    t.addEventListener('scroll', sync, { passive: true });
    window.addEventListener('resize', sync);
    if (auto > 0 && !reduce) {
      var start = function () { stop(); timer = setInterval(function () { var max = t.scrollWidth - t.clientWidth - 2; if (t.scrollLeft >= max) go(0); else go(index() + 1); }, auto * 1000); };
      var stop = function () { clearInterval(timer); };
      start();
      section.addEventListener('mouseenter', stop); section.addEventListener('mouseleave', start);
      section.addEventListener('touchstart', stop, { passive: true });
      if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { en[0].isIntersecting ? start() : stop(); }).observe(section);
    }
    sync();
  }

  /* ---------- tabs ---------- */
  function tabs(section) {
    var btns = section.querySelectorAll('[data-es-tab]');
    if (!btns.length) return;
    btns.forEach(function (b) {
      b.addEventListener('click', function () {
        var key = b.getAttribute('data-es-tab');
        btns.forEach(function (x) { x.classList.toggle('is-active', x === b); x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
        section.querySelectorAll('[data-es-panel]').forEach(function (p) { p.classList.toggle('is-active', p.getAttribute('data-es-panel') === key); });
        section.querySelectorAll('[data-es-cat]').forEach(function (it) { it.hidden = key !== 'all' && it.getAttribute('data-es-cat') !== key; });
        reveal(section);
      });
    });
  }

  /* ---------- dispatch timer: "order within 3h 12m for dispatch tomorrow" ---------- */
  function dispatch(section) {
    var el = section.querySelector('[data-es-dispatch]');
    if (!el) return;
    var cutoff = parseFloat(el.getAttribute('data-cutoff') || '14');   // hour of day, store time
    var offset = parseFloat(el.getAttribute('data-offset') || '10');   // store UTC offset in hours (AEST 10, AEDT 11, NZST 12, NZDT 13)
    var workdays = (el.getAttribute('data-workdays') || '1,2,3,4,5').split(',').map(Number);
    var out = el.querySelector('[data-es-dispatch-time]');
    var dayOut = el.querySelector('[data-es-dispatch-day]');
    var labels = { today: el.getAttribute('data-label-today') || 'today', tomorrow: el.getAttribute('data-label-tomorrow') || 'tomorrow', monday: el.getAttribute('data-label-monday') || 'on Monday', h: el.getAttribute('data-h') || 'h', m: el.getAttribute('data-m') || 'm' };
    function storeNow() { var d = new Date(); return new Date(d.getTime() + (d.getTimezoneOffset() * 60000) + offset * 3600000); }
    function nextWorkday(d) { var x = new Date(d); do { x.setDate(x.getDate() + 1); } while (workdays.indexOf(x.getDay()) === -1); return x; }
    function tick() {
      var now = storeNow();
      var target = new Date(now); target.setHours(Math.floor(cutoff), Math.round((cutoff % 1) * 60), 0, 0);
      var dispatchDay;
      if (workdays.indexOf(now.getDay()) !== -1 && now < target) { dispatchDay = labels.today; }
      else { target = nextWorkday(now); target.setHours(Math.floor(cutoff), Math.round((cutoff % 1) * 60), 0, 0); var diffDays = Math.round((new Date(target).setHours(0,0,0,0) - new Date(now).setHours(0,0,0,0)) / 86400000); dispatchDay = diffDays === 1 ? labels.tomorrow : labels.monday; }
      var ms = target - now, h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000);
      if (out) out.textContent = (h > 0 ? h + labels.h + ' ' : '') + m + labels.m;
      if (dayOut) dayOut.textContent = dispatchDay;
      el.hidden = false;
    }
    tick(); setInterval(tick, 30000);
  }

  /* ---------- countdown to a real end date ---------- */
  function countdown(section) {
    var el = section.querySelector('[data-es-count]');
    if (!el) return;
    var raw = el.getAttribute('data-end') || '';
    var offset = parseFloat(el.getAttribute('data-offset') || '10');
    var m = raw.match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
    if (!m) { el.hidden = true; return; }
    var end = Date.UTC(+m[1], m[2] - 1, +m[3], +m[4] - offset, +m[5]);
    var cells = { d: el.querySelector('[data-d]'), h: el.querySelector('[data-h]'), m: el.querySelector('[data-m]'), s: el.querySelector('[data-s]') };
    function pad(n) { return (n < 10 ? '0' : '') + n; }
    function tick() {
      var left = end - Date.now();
      if (left <= 0) { if (el.getAttribute('data-hide-when-done') === 'true') section.style.display = 'none'; else el.hidden = true; clearInterval(iv); return; }
      var d = Math.floor(left / 86400000), h = Math.floor(left % 86400000 / 3600000), mi = Math.floor(left % 3600000 / 60000), s = Math.floor(left % 60000 / 1000);
      if (cells.d) { cells.d.textContent = pad(d); cells.d.parentNode.hidden = d === 0 && el.getAttribute('data-hide-days') === 'true'; }
      if (cells.h) cells.h.textContent = pad(h);
      if (cells.m) cells.m.textContent = pad(mi);
      if (cells.s) cells.s.textContent = pad(s);
      el.hidden = false;
    }
    tick(); var iv = setInterval(tick, 1000);
  }

  /* ---------- shop the look hotspots ---------- */
  function look(section) {
    var dots = section.querySelectorAll('[data-es-dot]');
    if (!dots.length) return;
    var items = section.querySelectorAll('[data-es-look-item]');
    function activate(key) {
      dots.forEach(function (d) { d.classList.toggle('is-active', d.getAttribute('data-es-dot') === key); });
      items.forEach(function (it) { it.classList.toggle('is-active', it.getAttribute('data-es-look-item') === key); });
    }
    dots.forEach(function (d) {
      d.addEventListener('click', function () { var key = d.getAttribute('data-es-dot'); activate(key); var it = section.querySelector('[data-es-look-item="' + key + '"]'); if (it && window.innerWidth <= 768) it.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'nearest' }); });
      d.addEventListener('mouseenter', function () { activate(d.getAttribute('data-es-dot')); });
    });
    items.forEach(function (it) { it.addEventListener('mouseenter', function () { activate(it.getAttribute('data-es-look-item')); }); });
  }

  /* ---------- featured product: variant select + add to cart ---------- */
  function featured(section) {
    var form = section.querySelector('[data-es-fp-form]');
    if (!form) return;
    var select = form.querySelector('[data-es-fp-variants]');
    var idInput = form.querySelector('input[name="id"]');
    var btn = form.querySelector('[data-es-fp-atc]');
    var price = section.querySelector('[data-es-fp-price]');
    var compare = section.querySelector('[data-es-fp-compare]');
    var save = section.querySelector('[data-es-fp-save]');
    var err = section.querySelector('[data-es-fp-error]');
    var soldLabel = btn ? btn.getAttribute('data-sold-out') : 'Sold out';
    var addLabel = btn ? btn.getAttribute('data-add') : 'Add to cart';
    var money = function (cents) { var f = section.getAttribute('data-money') || '${{amount}}'; var n = (cents / 100).toFixed(2); return f.replace('{{amount}}', n.replace(/\B(?=(\d{3})+(?!\d))/g, ',')).replace('{{amount_no_decimals}}', Math.round(cents / 100)); };
    function update() {
      if (!select) return;
      var o = select.options[select.selectedIndex];
      if (!o) return;
      if (idInput) idInput.value = o.value;
      var p = parseInt(o.getAttribute('data-price'), 10), c = parseInt(o.getAttribute('data-compare') || '0', 10), avail = o.getAttribute('data-available') === 'true';
      if (price) price.textContent = money(p);
      if (compare) { compare.hidden = !(c > p); compare.textContent = c > p ? money(c) : ''; }
      if (save) { save.hidden = !(c > p); if (c > p) save.textContent = save.getAttribute('data-template').replace('[pct]', Math.round((c - p) * 100 / c)); }
      if (btn) { btn.disabled = !avail; btn.querySelector('span').textContent = avail ? addLabel : soldLabel; }
    }
    if (select) select.addEventListener('change', update);
    update();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!btn || btn.disabled) return;
      btn.classList.add('is-loading'); if (err) err.hidden = true;
      fetch(shopRoot + 'cart/add.js', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ items: [{ id: Number(idInput.value), quantity: 1 }] }) })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          if (!res.ok) throw new Error(res.j.description || res.j.message || 'Error');
          document.dispatchEvent(new CustomEvent('cart:add', { detail: res.j }));
          fetch(shopRoot + 'cart.js').then(function (r) { return r.json(); }).then(function (cart) { document.querySelectorAll('[data-cart-count]').forEach(function (c) { c.textContent = cart.item_count; c.classList.toggle('is-empty', cart.item_count === 0); }); }).catch(function () {});
          if (!document.querySelector('kaching-cart, [data-cart-drawer]')) window.location.href = shopRoot + 'cart';
        })
        .catch(function (ex) { if (err) { err.textContent = ex.message; err.hidden = false; } })
        .finally(function () { btn.classList.remove('is-loading'); });
    });
  }

  /* ---------- rating bars (animate width when visible) ---------- */
  function bars(section) {
    var fills = section.querySelectorAll('[data-es-fill]');
    if (!fills.length) return;
    var run = function () { fills.forEach(function (f) { f.style.width = f.getAttribute('data-es-fill') + '%'; }); };
    if (!('IntersectionObserver' in window)) return run();
    var io = new IntersectionObserver(function (en) { if (en[0].isIntersecting) { run(); io.disconnect(); } }, { threshold: 0.3 });
    io.observe(section);
  }

  /* ---------- size guide unit toggle ---------- */
  function units(section) {
    var btns = section.querySelectorAll('[data-es-unit]');
    if (!btns.length) return;
    var cells = section.querySelectorAll('[data-cm]');
    btns.forEach(function (b) {
      b.addEventListener('click', function () {
        var u = b.getAttribute('data-es-unit');
        btns.forEach(function (x) { x.classList.toggle('is-active', x === b); });
        cells.forEach(function (c) { var cm = parseFloat(c.getAttribute('data-cm')); if (isNaN(cm)) return; c.textContent = u === 'in' ? (Math.round(cm / 2.54 * 10) / 10) : cm; });
      });
    });
  }

  /* ---------- sticky offer bar ---------- */
  function sticky(section) {
    var bar = section.querySelector('[data-es-sticky]');
    if (!bar) return;
    var key = 'es_sticky_' + (bar.getAttribute('data-key') || 'bar');
    try { if (sessionStorage.getItem(key) === '1' && !document.body.classList.contains('shopify-design-mode')) return; } catch (e) {}
    if (bar.getAttribute('data-hide-product') === 'true' && document.body.classList.contains('template-product')) return;
    var delay = parseInt(bar.getAttribute('data-delay') || '2', 10) * 1000;
    var show = function () { bar.classList.add('is-on'); document.body.classList.add('es-has-sticky'); };
    var hide = function () { bar.classList.remove('is-on'); document.body.classList.remove('es-has-sticky'); try { sessionStorage.setItem(key, '1'); } catch (e) {} };
    var closeBtn = bar.querySelector('[data-es-sticky-close]');
    if (closeBtn) closeBtn.addEventListener('click', hide);
    if (bar.getAttribute('data-after-scroll') === 'true') {
      var once = function () { if (window.scrollY > 300) { show(); window.removeEventListener('scroll', once); } };
      window.addEventListener('scroll', once, { passive: true });
    } else { setTimeout(show, delay); }
  }

  /* ---------- video mute toggle ---------- */
  function video(section) {
    var v = section.querySelector('.es-video video');
    var b = section.querySelector('[data-es-mute]');
    if (!v) return;
    if (reduce) { v.removeAttribute('autoplay'); v.pause(); }
    if (b) b.addEventListener('click', function () { v.muted = !v.muted; b.setAttribute('aria-pressed', v.muted ? 'false' : 'true'); b.classList.toggle('is-sound', !v.muted); if (v.paused) v.play(); });
    if ('IntersectionObserver' in window && !reduce) new IntersectionObserver(function (en) { en[0].isIntersecting ? v.play().catch(function () {}) : v.pause(); }, { threshold: 0.2 }).observe(v);
  }

  /* ---------- marquee: duplicate content so it loops seamlessly ---------- */
  function marquee(section) {
    var t = section.querySelector('[data-es-marquee]');
    if (!t || t.children.length !== 1) return;
    var set = t.children[0];
    t.appendChild(set.cloneNode(true)).setAttribute('aria-hidden', 'true');
    var pxPerSec = parseFloat(section.getAttribute('data-es-speed') || '60');
    var w = set.getBoundingClientRect().width;
    if (w) t.style.setProperty('--es-speed', (w / pxPerSec) + 's');
  }

  function init(section) {
    if (!section || section.hasAttribute('data-es-ready')) return;
    section.setAttribute('data-es-ready', '');
    reveal(section); track(section); tabs(section); dispatch(section); countdown(section); look(section); featured(section); bars(section); units(section); sticky(section); video(section); marquee(section);
  }
  function initAll() { document.querySelectorAll('[data-es]:not([data-es-ready])').forEach(init); }
  window.CCTSections = { init: init, initAll: initAll };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initAll); else initAll();
  document.addEventListener('shopify:section:load', function (e) { var s = e.target.querySelector('[data-es]'); if (s) { s.removeAttribute('data-es-ready'); init(s); } });
})();
