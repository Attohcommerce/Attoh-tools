/* Consistent Couture – global polish (31-10-2026): soft image fade-in and a gentle reveal of product cards / tiles.
   Tiny, dependency-free, respects prefers-reduced-motion. Without JS nothing is hidden. */
(function () {
  var root = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduce) return;
  root.classList.add('cct-js');

  /* images: fade in when they arrive (only the ones not already loaded) */
  function fadeImages(scope) {
    scope.querySelectorAll('img[loading="lazy"]:not(.cct-img):not(.ux-card__image--alt):not(.ux-hero__img)').forEach(function (img) {
      img.classList.add('cct-img');
      if (img.complete && img.naturalWidth > 0) { img.classList.add('is-loaded'); return; }
      var done = function () { img.classList.add('is-loaded'); };
      img.addEventListener('load', done, { once: true });
      img.addEventListener('error', done, { once: true });
      setTimeout(done, 2500); /* never leave an image invisible */
    });
  }

  /* reveal: cards and tiles rise in as they enter the viewport */
  var SEL = '.ux-card, .ux-tile, .ux-cats__tile, .ux-shopcards__card';
  var pending = [];
  function show(el) { el.classList.add('is-in'); setTimeout(function () { el.style.transitionDelay = ''; }, 900); }
  var io = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { if (e.isIntersecting) { show(e.target); io.unobserve(e.target); } });
  }, { rootMargin: '0px 0px -6% 0px', threshold: 0.05 }) : null;
  var ticking = false;
  function sweep() {
    var vh = window.innerHeight;
    pending = pending.filter(function (el) {
      if (el.classList.contains('is-in')) return false;
      if (el.getBoundingClientRect().top < vh + 60) { show(el); if (io) io.unobserve(el); return false; }
      return true;
    });
  }
  function onScroll() { if (ticking) return; ticking = true; requestAnimationFrame(function () { ticking = false; sweep(); }); }
  function arm(scope) {
    var els = scope.querySelectorAll(SEL);
    els.forEach(function (el, i) {
      if (el.classList.contains('cct-rv')) return;
      el.classList.add('cct-rv');
      el.style.transitionDelay = ((i % 4) * 60) + 'ms';
      if (!io) { el.classList.add('is-in'); return; }
      io.observe(el); pending.push(el);
    });
    setTimeout(sweep, 80);
  }
  function init(scope) { fadeImages(scope || document); arm(scope || document); }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll);
  window.addEventListener('load', sweep);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); }); else init(document);
  document.addEventListener('shopify:section:load', function (e) { init(e.target); });
  /* theme editor: show everything at once so merchants never look at a hidden card */
  if (window.Shopify && window.Shopify.designMode) setTimeout(function () { document.querySelectorAll('.cct-rv:not(.is-in)').forEach(function (el) { el.classList.add('is-in'); }); }, 300);
})();
