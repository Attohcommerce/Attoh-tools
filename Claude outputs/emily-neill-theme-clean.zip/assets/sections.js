/* Section scripts (moved out of {% javascript %} tags). */

/* sections/announcement-bar.liquid */
(function () {
  try {
  class AnnouncementBarSection extends HTMLElement {
    connectedCallback() {
      if (this.dataset.mode !== 'slider') return;

      this.slides = Array.from(this.querySelectorAll('.announcement-bar__slide'));
      if (this.slides.length <= 1) return;

      this.currentIndex = this.slides.findIndex((slide) => slide.classList.contains('is-active'));
      if (this.currentIndex < 0) this.currentIndex = 0;
      this.isAnimating = false;
      this.animationDuration = 450;

      this.prevButton = this.querySelector('.announcement-bar__button--prev');
      this.nextButton = this.querySelector('.announcement-bar__button--next');

      this.handlePrev = () => this.showSlide(this.currentIndex - 1);
      this.handleNext = () => this.showSlide(this.currentIndex + 1);

      if (this.prevButton) this.prevButton.addEventListener('click', this.handlePrev);
      if (this.nextButton) this.nextButton.addEventListener('click', this.handleNext);

      if (this.dataset.autoplay === 'true' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        this.startAutoplay();
        this.addEventListener('mouseenter', this.stopAutoplay.bind(this));
        this.addEventListener('mouseleave', this.startAutoplay.bind(this));
      }
    }

    disconnectedCallback() {
      if (this.prevButton) this.prevButton.removeEventListener('click', this.handlePrev);
      if (this.nextButton) this.nextButton.removeEventListener('click', this.handleNext);
      this.stopAutoplay();
    }

    showSlide(index) {
      if (this.isAnimating) return;

      const total = this.slides.length;
      const nextIndex = (index + total) % total;
      if (nextIndex === this.currentIndex) return;

      const currentSlide = this.slides[this.currentIndex];
      const nextSlide = this.slides[nextIndex];

      this.isAnimating = true;
      currentSlide.classList.add('is-leaving');
      currentSlide.classList.remove('is-active');
      nextSlide.classList.add('is-active');

      window.setTimeout(() => {
        currentSlide.classList.remove('is-leaving');
        this.currentIndex = nextIndex;
        this.isAnimating = false;
      }, this.animationDuration);
    }

    startAutoplay() {
      this.stopAutoplay();
      const interval = Number(this.dataset.interval) || 4000;
      this.autoplayTimer = window.setInterval(() => this.showSlide(this.currentIndex + 1), interval);
    }

    stopAutoplay() {
      if (this.autoplayTimer) {
        window.clearInterval(this.autoplayTimer);
        this.autoplayTimer = null;
      }
    }
  }

  if (!customElements.get('announcement-bar-section')) {
    customElements.define('announcement-bar-section', AnnouncementBarSection);
  }
  } catch (e) { console.error('sections/announcement-bar.liquid', e); }
})();

/* sections/background-image-text.liquid */
(function () {
  try {
  (() => {
    const section = document.currentScript?.closest('.shopify-section')?.querySelector('.background-image-text-section');

    if (!section || section.dataset.parallax !== 'true') return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const media = section.querySelector('[data-background-media]');
    if (!media) return;

    let ticking = false;

    const updateParallax = () => {
      const rect = section.getBoundingClientRect();
      const progress = (window.innerHeight - rect.top) / (window.innerHeight + rect.height);
      const shift = (progress - 0.5) * 28;
      const axis = getComputedStyle(section).getPropertyValue('--background-image-text-parallax-axis').trim();

      if (axis === 'horizontal') {
        media.style.transform = `translate3d(${shift}px, 0, 0) scale(1.06)`;
      } else {
        media.style.transform = `translate3d(0, ${shift}px, 0) scale(1.06)`;
      }
      ticking = false;
    };

    const requestUpdate = () => {
      if (window.innerWidth <= 749) {
        media.style.transform = 'none';
        return;
      }

      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(updateParallax);
    };

    updateParallax();
    document.addEventListener('scroll', requestUpdate, { passive: true });
    window.addEventListener('resize', requestUpdate);
  })();
  } catch (e) { console.error('sections/background-image-text.liquid', e); }
})();

/* sections/faq.liquid */
(function () {
  try {
  class FaqSection extends HTMLElement {
    connectedCallback() {
      this._items = Array.from(this.querySelectorAll('details.faq-item'));
      this._items.forEach((item) => {
        item.addEventListener('toggle', () => {
          if (item.open) {
            this._items.forEach((other) => {
              if (other !== item) other.removeAttribute('open');
            });
          }
        });
      });
    }
  }

  if (!customElements.get('faq-section')) {
    customElements.define('faq-section', FaqSection);
  }
  } catch (e) { console.error('sections/faq.liquid', e); }
})();

/* sections/hero.liquid */
(function () {
  try {
  (() => {
    const section = document.currentScript?.closest('.shopify-section')?.querySelector('.hero-section');

    if (!section) return;

    const slides = Array.from(section.querySelectorAll('[data-hero-slide]'));
    const dots = Array.from(section.querySelectorAll('[data-hero-dot]'));
    const prevButton = section.querySelector('[data-hero-prev]');
    const nextButton = section.querySelector('[data-hero-next]');
    const autoplay = section.dataset.autoplay === 'true';
    const autoplaySpeed = Number(section.dataset.autoplaySpeed) || 5000;
    const parallaxEnabled = section.dataset.parallax === 'true';
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const mediaItems = Array.from(section.querySelectorAll('[data-hero-media]'));
    let activeIndex = slides.findIndex((slide) => slide.classList.contains('is-active'));
    let autoplayTimer = null;

    if (activeIndex < 0) activeIndex = 0;

    const updateSlides = (index) => {
      slides.forEach((slide, slideIndex) => {
        const isActive = slideIndex === index;
        slide.classList.toggle('is-active', isActive);
      });

      dots.forEach((dot, dotIndex) => {
        const isActive = dotIndex === index;
        dot.classList.toggle('is-active', isActive);
        dot.setAttribute('aria-current', isActive ? 'true' : 'false');
      });

      activeIndex = index;
    };

    const goToSlide = (index) => {
      const normalizedIndex = (index + slides.length) % slides.length;
      updateSlides(normalizedIndex);
    };

    const startAutoplay = () => {
      if (!autoplay || prefersReducedMotion || slides.length < 2) return;
      window.clearInterval(autoplayTimer);
      autoplayTimer = window.setInterval(() => {
        goToSlide(activeIndex + 1);
      }, autoplaySpeed);
    };

    const stopAutoplay = () => {
      window.clearInterval(autoplayTimer);
    };

    prevButton?.addEventListener('click', () => {
      goToSlide(activeIndex - 1);
      startAutoplay();
    });

    nextButton?.addEventListener('click', () => {
      goToSlide(activeIndex + 1);
      startAutoplay();
    });

    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        goToSlide(index);
        startAutoplay();
      });
    });

    section.addEventListener('mouseenter', stopAutoplay);
    section.addEventListener('mouseleave', startAutoplay);

    if (parallaxEnabled && !prefersReducedMotion) {
      let ticking = false;

      const updateParallax = () => {
        const rect = section.getBoundingClientRect();
        const progress = (window.innerHeight - rect.top) / (window.innerHeight + rect.height);
        const translateY = (progress - 0.5) * 40;

        mediaItems.forEach((media) => {
          media.style.transform = `translate3d(0, ${translateY}px, 0) scale(1.08)`;
        });

        ticking = false;
      };

      const requestParallaxUpdate = () => {
        if (ticking) return;
        ticking = true;
        window.requestAnimationFrame(updateParallax);
      };

      updateParallax();
      document.addEventListener('scroll', requestParallaxUpdate, { passive: true });
      window.addEventListener('resize', requestParallaxUpdate);
    }

    updateSlides(activeIndex);
    startAutoplay();
  })();
  } catch (e) { console.error('sections/hero.liquid', e); }
})();
