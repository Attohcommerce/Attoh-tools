/* Storefront behaviour: header, drawers, collection tools and product page. */
(function () {
  'use strict';
  const mqMobile = window.matchMedia('(max-width: 768px)');
  const lockScroll = (on) => { document.documentElement.style.overflow = on ? 'hidden' : ''; };

  /* ---------- announcement rotator ---------- */
  if (!customElements.get('ux-rotator')) {
    customElements.define('ux-rotator', class extends HTMLElement {
      connectedCallback() {
        this.slides = [...this.querySelectorAll('.ux-announce__slide')];
        if (this.slides.length < 2) return;
        this.i = 0;
        const ms = (parseInt(this.dataset.interval, 10) || 4) * 1000;
        this.timer = setInterval(() => {
          this.slides[this.i].classList.remove('is-active');
          this.i = (this.i + 1) % this.slides.length;
          this.slides[this.i].classList.add('is-active');
        }, ms);
      }
      disconnectedCallback() { clearInterval(this.timer); }
    });
  }

  /* ---------- header: mega menu, search, sticky ---------- */
  if (!customElements.get('ux-header')) {
    customElements.define('ux-header', class extends HTMLElement {
      connectedCallback() {
        this.items = [...this.querySelectorAll('[data-mega-item]')];
        this.items.forEach((item) => {
          let t;
          const link = item.querySelector('.ux-nav__link');
          const open = () => { clearTimeout(t); this.closeAll(item); item.classList.add('is-open'); link.setAttribute('aria-expanded', 'true'); };
          const close = () => { t = setTimeout(() => { item.classList.remove('is-open'); link.setAttribute('aria-expanded', 'false'); }, 120); };
          item.addEventListener('mouseenter', () => { if (!mqMobile.matches) open(); });
          item.addEventListener('mouseleave', close);
          item.addEventListener('focusin', open);
          item.addEventListener('focusout', (e) => { if (!item.contains(e.relatedTarget)) close(); });
        });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { this.closeAll(); this.toggleSearch(false); } });

        this.search = this.querySelector('#UxSearch');
        this.querySelectorAll('[data-search-open]').forEach((b) => b.addEventListener('click', () => this.toggleSearch(this.search && this.search.hidden)));
        this.querySelectorAll('[data-search-close]').forEach((b) => b.addEventListener('click', () => this.toggleSearch(false)));

        const section = this.closest('.shopify-section');
        if (this.classList.contains('ux-header--sticky') && section) {
          section.style.position = 'sticky';
          section.style.top = '0';
          section.style.zIndex = '30';
          const onScroll = () => this.classList.toggle('is-stuck', window.scrollY > 10);
          window.addEventListener('scroll', onScroll, { passive: true });
          onScroll();
        }
      }
      closeAll(except) {
        this.items.forEach((i) => { if (i !== except) { i.classList.remove('is-open'); const l = i.querySelector('.ux-nav__link'); if (l) l.setAttribute('aria-expanded', 'false'); } });
      }
      toggleSearch(show) {
        if (!this.search) return;
        this.search.hidden = !show;
        this.querySelectorAll('[data-search-open]').forEach((b) => b.setAttribute('aria-expanded', show ? 'true' : 'false'));
        if (show) { this.closeAll(); const input = this.search.querySelector('input[type="search"]'); if (input) setTimeout(() => input.focus(), 30); }
      }
    });
  }

  /* ---------- mobile nav drawer ---------- */
  if (!customElements.get('ux-drawer')) {
    customElements.define('ux-drawer', class extends HTMLElement {
      connectedCallback() {
        this.panel = this.querySelector('.ux-drawer__panel');
        document.querySelectorAll('[data-drawer-open][aria-controls="' + this.id + '"]').forEach((b) => b.addEventListener('click', () => this.open(b)));
        this.querySelectorAll('[data-drawer-close]').forEach((b) => b.addEventListener('click', () => this.close()));
        this.addEventListener('keydown', (e) => { if (e.key === 'Escape') this.close(); });
        this.querySelectorAll('.ux-mnav__details > summary a').forEach((a) => {
          a.addEventListener('click', (e) => {
            const details = a.closest('details');
            if (details && !details.open) { e.preventDefault(); details.open = true; }
          });
        });
      }
      open(trigger) {
        this.trigger = trigger;
        this.classList.add('is-open');
        this.setAttribute('aria-hidden', 'false');
        if (trigger) trigger.setAttribute('aria-expanded', 'true');
        lockScroll(true);
        setTimeout(() => this.panel.focus(), 50);
      }
      close() {
        this.classList.remove('is-open');
        this.setAttribute('aria-hidden', 'true');
        if (this.trigger) { this.trigger.setAttribute('aria-expanded', 'false'); this.trigger.focus(); }
        lockScroll(false);
      }
    });
  }

  /* ---------- footer accordions (closed on mobile) ---------- */
  const syncFooter = () => {
    document.querySelectorAll('[data-footer-acc]').forEach((d) => { d.open = !mqMobile.matches; });
  };
  syncFooter();
  if (mqMobile.addEventListener) mqMobile.addEventListener('change', syncFooter);
  document.querySelectorAll('[data-footer-acc] > summary').forEach((s) => {
    s.addEventListener('click', (e) => { if (!mqMobile.matches) e.preventDefault(); });
  });
  document.querySelectorAll('[data-back-to-top]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }));

  /* ---------- collection: sort + filters ---------- */
  document.querySelectorAll('[data-sort]').forEach((select) => {
    select.addEventListener('change', () => {
      const url = new URL(window.location.href);
      url.searchParams.set('sort_by', select.value);
      url.searchParams.delete('page');
      window.location.href = url.toString();
    });
  });
  document.querySelectorAll('[data-filter-form]').forEach((form) => {
    const submit = () => {
      const params = new URLSearchParams(new FormData(form));
      [...params.keys()].forEach((k) => { if (params.get(k) === '') params.delete(k); });
      window.location.href = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
    };
    form.addEventListener('submit', (e) => { e.preventDefault(); submit(); });
    form.querySelectorAll('input[type="checkbox"]').forEach((c) => c.addEventListener('change', () => { if (!mqMobile.matches) submit(); }));
    form.querySelectorAll('input[type="number"]').forEach((n) => n.addEventListener('change', () => { if (!mqMobile.matches) submit(); }));
  });
  const rail = document.getElementById('UxFilterDrawer');
  if (rail) {
    document.querySelectorAll('[data-filter-open]').forEach((b) => b.addEventListener('click', () => { rail.classList.add('is-open'); lockScroll(true); }));
    rail.querySelectorAll('[data-filter-close]').forEach((b) => b.addEventListener('click', () => { rail.classList.remove('is-open'); lockScroll(false); }));
    rail.addEventListener('click', (e) => { if (e.target === rail) { rail.classList.remove('is-open'); lockScroll(false); } });
  }

  /* ---------- related products ---------- */
  if (!customElements.get('ux-related')) {
    customElements.define('ux-related', class extends HTMLElement {
      connectedCallback() {
        if (this.children.length || !this.dataset.url) return;
        const load = () => fetch(this.dataset.url).then((r) => r.text()).then((html) => {
          const doc = new DOMParser().parseFromString(html, 'text/html');
          const fresh = doc.querySelector('ux-related');
          if (fresh && fresh.innerHTML.trim()) this.innerHTML = fresh.innerHTML;
        }).catch(() => {});
        if ('IntersectionObserver' in window) {
          const io = new IntersectionObserver((entries) => { if (entries.some((e) => e.isIntersecting)) { io.disconnect(); load(); } }, { rootMargin: '0px 0px 400px 0px' });
          io.observe(this);
        } else { load(); }
      }
    });
  }

  /* ---------- product page ---------- */
  const formatMoney = (cents, format) => {
    const value = (cents / 100).toFixed(2);
    const [whole, dec] = value.split('.');
    const withCommas = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    const fmt = format || '${{amount}}';
    return fmt.replace(/\{\{\s*(\w+)\s*\}\}/, (m, key) => {
      if (key === 'amount_no_decimals') return withCommas;
      if (key === 'amount_with_comma_separator') return whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + dec;
      if (key === 'amount_no_decimals_with_comma_separator') return whole.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
      return withCommas + '.' + dec;
    });
  };
  const addBusinessDays = (date, days) => {
    const d = new Date(date);
    let added = 0;
    while (added < days) { d.setDate(d.getDate() + 1); const day = d.getDay(); if (day !== 0 && day !== 6) added++; }
    return d;
  };

  document.querySelectorAll('[data-pdp]').forEach((root) => {
    const jsonEl = root.querySelector('[data-product-json]');
    const data = jsonEl ? JSON.parse(jsonEl.textContent) : { variants: [] };
    const variants = data.variants || [];
    const optionEls = [...root.querySelectorAll('[data-option-index]')];
    const idInput = root.querySelector('[data-variant-id]');
    const atc = root.querySelector('[data-atc]');
    const atcLabel = root.querySelector('[data-atc-label]');
    const track = root.querySelector('[data-track]');
    const slides = track ? [...track.children] : [];
    const thumbs = [...root.querySelectorAll('[data-thumb]')];
    const dots = [...root.querySelectorAll('.ux-pdp__dot')];
    const sticky = root.querySelector('[data-sticky-bar]');
    const form = root.querySelector('[data-product-form]');
    const errorEl = root.querySelector('[data-form-error]');

    const selected = () => optionEls.map((el) => {
      const active = el.querySelector('.is-active, .is-selected');
      return active ? active.dataset.value : null;
    });
    const findVariant = (opts) => variants.find((v) => v.options.every((o, i) => opts[i] == null || o === opts[i]));

    const goTo = (index, smooth = true) => {
      if (!track || !slides[index]) return;
      track.scrollTo({ left: slides[index].offsetLeft - track.offsetLeft, behavior: smooth ? 'smooth' : 'auto' });
      setActive(index);
    };
    const setActive = (index) => {
      thumbs.forEach((t, i) => t.classList.toggle('is-active', i === index));
      dots.forEach((d, i) => d.classList.toggle('is-active', i === index));
    };
    thumbs.forEach((t, i) => t.addEventListener('click', () => goTo(i)));
    if (track) {
      let raf;
      track.addEventListener('scroll', () => {
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => {
          const i = Math.round(track.scrollLeft / Math.max(1, track.clientWidth));
          setActive(Math.min(slides.length - 1, Math.max(0, i)));
        });
      }, { passive: true });
    }

    const markAvailability = (opts) => {
      optionEls.forEach((el, idx) => {
        el.querySelectorAll('[data-value]').forEach((btn) => {
          const test = opts.slice(); test[idx] = btn.dataset.value;
          const match = variants.find((v) => v.available && v.options.every((o, i) => test[i] == null || o === test[i]));
          btn.classList.toggle('is-unavailable', !match);
        });
      });
    };

    const update = (variant) => {
      if (!variant) {
        if (atc) { atc.disabled = true; if (atcLabel) atcLabel.textContent = atc.dataset.labelSold; }
        return;
      }
      if (idInput) idInput.value = variant.id;
      const now = root.querySelector('[data-price-now]');
      const cmp = root.querySelector('[data-price-compare]');
      const save = root.querySelector('[data-price-save]');
      if (now) now.textContent = formatMoney(variant.price, data.moneyFormat);
      const onSale = variant.compare > variant.price;
      if (cmp) { cmp.hidden = !onSale; if (onSale) cmp.textContent = formatMoney(variant.compare, data.moneyFormat); }
      if (save) { save.hidden = !onSale; const pct = save.querySelector('[data-save-pct]'); if (pct && onSale) pct.textContent = Math.round(((variant.compare - variant.price) * 100) / variant.compare); }
      if (atc) { atc.disabled = !variant.available; if (atcLabel) atcLabel.textContent = variant.available ? atc.dataset.labelAdd : atc.dataset.labelSold; }
      const stock = root.querySelector('[data-stock]');
      if (stock) {
        stock.classList.toggle('is-in', variant.available);
        stock.classList.toggle('is-out', !variant.available);
        const t = stock.querySelector('[data-stock-text]');
        if (t) t.textContent = variant.available ? stock.dataset.in : stock.dataset.out;
      }
      if (sticky) {
        const sp = sticky.querySelector('[data-sticky-price]');
        if (sp) sp.textContent = formatMoney(variant.price, data.moneyFormat);
        const sb = sticky.querySelector('[data-sticky-atc]');
        if (sb) sb.disabled = !variant.available;
      }
      if (variant.media) {
        const idx = slides.findIndex((s) => String(s.dataset.mediaId) === String(variant.media));
        if (idx > -1) goTo(idx);
      }
      const url = new URL(window.location.href);
      url.searchParams.set('variant', variant.id);
      window.history.replaceState({}, '', url.toString());
    };

    optionEls.forEach((el) => {
      el.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-value]');
        if (!btn) return;
        el.querySelectorAll('[data-value]').forEach((b) => { b.classList.remove('is-active', 'is-selected'); b.setAttribute('aria-checked', 'false'); });
        btn.classList.add(btn.classList.contains('ux-pdp__swatch') ? 'is-active' : 'is-selected');
        btn.setAttribute('aria-checked', 'true');
        const label = el.querySelector('[data-option-value]');
        if (label) label.textContent = btn.dataset.value;
        let opts = selected();
        let variant = variants.find((v) => v.options.every((o, i) => o === opts[i]));
        if (!variant || !variant.available) {
          // keep the clicked value, pick the first available combination for the other options
          const idx = optionEls.indexOf(el);
          const alt = variants.find((v) => v.available && v.options[idx] === btn.dataset.value);
          if (alt && !variant) {
            alt.options.forEach((val, i) => {
              if (i === idx) return;
              const group = optionEls[i];
              group.querySelectorAll('[data-value]').forEach((b) => {
                const on = b.dataset.value === val;
                b.classList.toggle(b.classList.contains('ux-pdp__swatch') ? 'is-active' : 'is-selected', on);
                b.setAttribute('aria-checked', on ? 'true' : 'false');
              });
              const lbl = group.querySelector('[data-option-value]');
              if (lbl) lbl.textContent = val;
            });
            variant = alt;
          }
        }
        opts = selected();
        markAvailability(opts);
        update(variant || findVariant(opts));
      });
    });
    if (optionEls.length) markAvailability(selected());

    // add to cart
    const afterAdd = root.closest('.shopify-section') ? (root.dataset.afterAdd || 'cart') : 'cart';
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!atc || atc.disabled) return;
        atc.classList.add('is-loading');
        if (errorEl) errorEl.hidden = true;
        fetch((window.Shopify && window.Shopify.routes ? window.Shopify.routes.root : '/') + 'cart/add.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({ items: [{ id: Number(idInput.value), quantity: 1 }] }),
        })
          .then((r) => r.json().then((j) => ({ ok: r.ok, j })))
          .then(({ ok, j }) => {
            if (!ok) throw new Error(j.description || j.message || 'Error');
            document.dispatchEvent(new CustomEvent('cart:add', { detail: j }));
            fetch('/cart.js').then((r) => r.json()).then((cart) => {
              document.querySelectorAll('[data-cart-count]').forEach((c) => { c.textContent = cart.item_count; c.classList.toggle('is-empty', cart.item_count === 0); });
            }).catch(() => {});
            if (afterAdd === 'cart' && !document.querySelector('kaching-cart, [data-cart-drawer]')) window.location.href = (window.Shopify && window.Shopify.routes ? window.Shopify.routes.root : '/') + 'cart';
          })
          .catch((err) => { if (errorEl) { errorEl.textContent = err.message; errorEl.hidden = false; } })
          .finally(() => atc.classList.remove('is-loading'));
      });
    }

    // sticky bar
    if (sticky && atc) {
      const btn = sticky.querySelector('[data-sticky-atc]');
      if (btn) btn.addEventListener('click', () => { if (form) form.requestSubmit ? form.requestSubmit() : atc.click(); });
      if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver(([entry]) => {
          const show = !entry.isIntersecting && entry.boundingClientRect.top < 0;
          sticky.classList.toggle('is-visible', show);
          sticky.setAttribute('aria-hidden', show ? 'false' : 'true');
        });
        io.observe(atc);
      }
    }

    // size guide
    const guide = root.querySelector('#UxSizeGuide');
    if (guide) {
      root.querySelectorAll('[data-guide-open]').forEach((b) => b.addEventListener('click', () => { guide.hidden = false; lockScroll(true); }));
      guide.querySelectorAll('[data-guide-close]').forEach((b) => b.addEventListener('click', () => { guide.hidden = true; lockScroll(false); }));
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !guide.hidden) { guide.hidden = true; lockScroll(false); } });
    }

    // delivery estimate
    root.querySelectorAll('[data-delivery]').forEach((el) => {
      const min = parseInt(el.dataset.min, 10) || 5;
      const max = parseInt(el.dataset.max, 10) || 10;
      const fmt = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const out = el.querySelector('[data-delivery-range]');
      if (out) out.textContent = fmt(addBusinessDays(new Date(), min)) + ' - ' + fmt(addBusinessDays(new Date(), max));
    });
  });
})();

/* PDP thumbs: actieve foto altijd in beeld in de scrollbare strip + fade als er meer is (30-10) */
(() => {
  const init = (box) => {
    if (!box || box.dataset.uxThumbs) return;
    box.dataset.uxThumbs = '1';
    const update = () => box.classList.toggle('has-more', box.scrollTop + box.clientHeight < box.scrollHeight - 4);
    const reveal = (t) => {
      const b = box.getBoundingClientRect();
      const r = t.getBoundingClientRect();
      if (r.top < b.top) box.scrollTop += r.top - b.top - 8;
      else if (r.bottom > b.bottom - 56) box.scrollTop += r.bottom - b.bottom + 64;
      if (r.left < b.left) box.scrollLeft += r.left - b.left - 8;
      else if (r.right > b.right) box.scrollLeft += r.right - b.right + 8;
    };
    box.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    window.addEventListener('load', update);
    new MutationObserver((list) => {
      list.forEach((m) => { if (m.target !== box && m.target.classList.contains('is-active')) reveal(m.target); });
    }).observe(box, { subtree: true, attributes: true, attributeFilter: ['class'] });
    update();
  };
  const run = () => document.querySelectorAll('.ux-pdp__thumbs').forEach(init);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
  document.addEventListener('shopify:section:load', run);
})();
