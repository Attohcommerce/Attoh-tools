/* Pull Society — fun-laag (10-11-2026): scroll-reveal, scroll-progress, header-schaduw,
   sets-marquee onder de strip. Geen afhankelijkheden. */
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // 1. Scroll-reveal: elementen taggen en met IntersectionObserver zichtbaar maken
  var single = ['.ux-section-head', '.ps-related__head', '.ps-setf__banner', '.ps-why__foot', '.section-newsletter .ux-page', '.ps-soon3__head', '.ps-cases', '.ps-calendar__row'];
  var grouped = ['.ps-type', '.ps-setf__tab', '.ps-card', '.ps-why__card', '.ps-strip__item', '.ux-faq__item', '.ux-section-faq details'];
  var all = single.concat(grouped);
  var els = document.querySelectorAll(all.join(','));
  for (var i = 0; i < els.length; i++) {
    if (els[i].closest('.ux-pdp, .ps-mega, .ux-mega, .ux-drawer')) continue;
    // Kaarten en tegels in een horizontale rail niet laten 'invliegen' (die staan buiten beeld tot je schuift)
    if (els[i].matches('.ps-card, .ps-setf__tab') && els[i].closest('.ps-setf__track, .ps-setf__tabs')) continue;
    els[i].classList.add('ps-rv');
  }
  grouped.forEach(function (s) {
    var byParent = new Map();
    document.querySelectorAll(s).forEach(function (el) {
      if (!el.classList.contains('ps-rv')) return;
      var p = el.parentElement;
      var n = byParent.get(p) || 0;
      byParent.set(p, n + 1);
      el.style.setProperty('--rv-i', Math.min(n, 10));
    });
  });
  var rv = document.querySelectorAll('.ps-rv');
  if (reduce || !('IntersectionObserver' in window)) {
    rv.forEach(function (e) { e.classList.add('is-in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });
    rv.forEach(function (e) { io.observe(e); });
    // Veiligheidsnet: wat in beeld staat maar nog verborgen is, alsnog tonen (na laden en na elke scroll-stop)
    var sweep = function () {
      document.querySelectorAll('.ps-rv:not(.is-in)').forEach(function (e) {
        var r = e.getBoundingClientRect();
        if (r.top < window.innerHeight + 40 && r.bottom > -40) e.classList.add('is-in');
      });
    };
    setTimeout(sweep, 1500);
    var st;
    window.addEventListener('scroll', function () { clearTimeout(st); st = setTimeout(sweep, 180); }, { passive: true });
  }

  // 2. Scroll-progress + header-schaduw
  var bar = document.createElement('div');
  bar.className = 'ps-progress';
  bar.setAttribute('aria-hidden', 'true');
  document.body.appendChild(bar);
  var ticking = false;
  function onScroll() {
    var h = document.documentElement;
    var max = h.scrollHeight - h.clientHeight;
    var p = max > 0 ? h.scrollTop / max : 0;
    bar.style.transform = 'scaleX(' + p + ')';
    document.body.classList.toggle('is-scrolled', h.scrollTop > 24);
    ticking = false;
  }
  window.addEventListener('scroll', function () {
    if (!ticking) { ticking = true; window.requestAnimationFrame(onScroll); }
  }, { passive: true });
  onScroll();

  // 3. Sets-marquee onder de USP-strip (alleen homepage), gevuld uit het Sets-menu
  var strip = document.querySelector('.ps-strip');
  var sets = Array.prototype.slice.call(document.querySelectorAll('.ps-mega-set')).slice(0, 16);
  if (strip && sets.length > 3 && document.body.classList.contains('template-index') && !document.querySelector('.ps-marquee')) {
    var m = document.createElement('div');
    m.className = 'ps-marquee';
    var track = document.createElement('div');
    track.className = 'ps-marquee__track';
    function items() {
      return sets.map(function (a) {
        var n = a.querySelector('.ps-mega-set__name');
        var c = a.querySelector('.ps-setf__tab-code');
        return '<a class="ps-marquee__item" href="' + a.getAttribute('href') + '"><b>' + (n ? n.textContent.trim() : '') + '</b>' + (c ? '<span>' + c.textContent.trim() + '</span>' : '') + '</a>';
      }).join('');
    }
    track.innerHTML = items() + items();
    m.appendChild(track);
    strip.insertAdjacentElement('afterend', m);
  }
})();
